import React from 'react';
import { Link } from 'react-router-dom';
import treatmentsData from '../data/treatmentsData';

const TreatmentsSection = () => {
  // Display only featured treatments on homepage
  const featuredTreatments = treatmentsData.filter(treatment => treatment.featured).slice(0, 4);
  
  return (
    <section className="py-20 bg-neutral-lightest">
      <div className="container mx-auto px-4">
        <h2 className="section-title font-serif text-neutral-darkest">Our Premium Medical Treatments</h2>
        <p className="section-subtitle">
          Discover our world-class medical treatments combined with luxury Istanbul experiences
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {featuredTreatments.map((treatment) => (
            <div key={treatment.id} className="treatment-card group">
              <div className="relative overflow-hidden">
                <img 
                  src={treatment.image || "https://placehold.co/600x400/4fc3f7/ffffff?text=Treatment"} 
                  alt={treatment.title}
                  className="treatment-image transition-transform duration-500 group-hover:scale-110"
                  crossOrigin="anonymous"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-4 text-white">
                    <p className="font-bold">{treatment.title}</p>
                    <p className="text-sm">{treatment.shortDescription}</p>
                  </div>
                </div>
              </div>
              <div className="treatment-content">
                <h3 className="treatment-title">{treatment.title}</h3>
                <p className="text-neutral-dark mb-3">{treatment.shortDescription}</p>
                <p className="treatment-price">
                  {treatment.price === 'Price on Request' 
                    ? 'Price on Request' 
                    : `Starting from $${treatment.price.toLocaleString()}`
                  }
                </p>
                <div className="treatment-features">
                  <div className="treatment-feature">
                    <i className="bi bi-calendar-check"></i>
                    <span>{treatment.duration} Stay</span>
                  </div>
                  <div className="treatment-feature">
                    <i className="bi bi-airplane"></i>
                    <span>{treatment.tourIncluded}</span>
                  </div>
                </div>
                <Link 
                  to={`/treatments/${treatment.id}`} 
                  className="btn btn-primary w-full"
                >
                  View Details
                </Link>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link to="/treatments" className="btn btn-primary">
            View All Treatments
          </Link>
        </div>
      </div>
    </section>
  );
};

export default TreatmentsSection;
