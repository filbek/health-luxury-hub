import React from 'react';
import { Link } from 'react-router-dom';

const HeroSection = () => {
  return (
    <section className="hero-video-container">
      {/* Video Background */}
      <video 
        className="hero-video"
        autoPlay 
        muted 
        loop 
        playsInline
        poster="https://images.unsplash.com/photo-1596941248238-0d49dcaa4263?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80"
      >
        <source 
          src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4" 
          type="video/mp4" 
        />
        Your browser does not support the video tag.
      </video>
      
      {/* Overlay */}
      <div className="hero-overlay"></div>
      
      {/* Content */}
      <div className="hero-content">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 font-serif">
          World-Class Medical Care <br />in Beautiful Istanbul
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-3xl">
          Experience premium healthcare combined with the rich cultural heritage of Turkey
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Link to="/contact" className="btn btn-primary">
            <i className="bi bi-calendar-check mr-2"></i>
            Get Free Consultation
          </Link>
          <a href="https://wa.me/905000000000" target="_blank" rel="noopener noreferrer" className="btn bg-green-500 hover:bg-green-600 text-white">
            <i className="bi bi-whatsapp mr-2"></i>
            Chat on WhatsApp
          </a>
          <Link to="/treatments" className="btn btn-outline">
            <i className="bi bi-airplane mr-2"></i>
            Explore Packages
          </Link>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
