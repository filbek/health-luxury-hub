import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const TestimonialsSection = () => {
  const testimonials = [
    {
      id: 1,
      name: 'Sarah Johnson',
      location: 'United Kingdom',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80',
      text: 'My limb lengthening surgery in Istanbul was life-changing. The medical care was exceptional, and exploring the city during my recovery was an unexpected bonus. The Bosphorus cruise was magical!',
      treatment: 'Limb Lengthening Surgery'
    },
    {
      id: 2,
      name: 'Ahmed Al-Farsi',
      location: 'United Arab Emirates',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80',
      text: 'The gastric sleeve procedure was seamless, and the results exceeded my expectations. The staff was attentive, and the hotel accommodation was luxurious. I enjoyed the Grand Bazaar tour during my recovery.',
      treatment: 'Obesity Surgery'
    },
    {
      id: 3,
      name: 'Elena Petrova',
      location: 'Russia',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80',
      text: 'My Hollywood Smile procedure transformed not just my appearance but my confidence. The dental team was professional, and the cultural tour of Istanbul was the perfect way to celebrate my new smile.',
      treatment: 'Dental Surgery'
    },
    {
      id: 4,
      name: 'Carlos Rodriguez',
      location: 'Spain',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80',
      text: 'The hair transplant results are amazing! The procedure was painless, and the team made me feel comfortable throughout. Exploring Hagia Sophia during my stay was an incredible experience.',
      treatment: 'Hair Transplant'
    }
  ];

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 640,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="section-title font-serif text-neutral-darkest">Patient Success Stories</h2>
        <p className="section-subtitle">
          Hear from our patients who experienced our premium medical care and Istanbul's cultural treasures
        </p>
        
        <Slider {...settings} className="testimonial-slider">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="px-3 pb-6">
              <div className="testimonial-card h-full flex flex-col">
                <div className="testimonial-header">
                  <img 
                    src={testimonial.image || "https://placehold.co/100x100/4fc3f7/ffffff?text=Patient"} 
                    alt={testimonial.name}
                    className="testimonial-image"
                    crossOrigin="anonymous"
                  />
                  <div>
                    <h4 className="testimonial-name">{testimonial.name}</h4>
                    <p className="testimonial-location">{testimonial.location}</p>
                    <p className="text-primary text-sm">{testimonial.treatment}</p>
                  </div>
                </div>
                <div className="mt-4 mb-2">
                  <i className="bi bi-star-fill text-yellow-400"></i>
                  <i className="bi bi-star-fill text-yellow-400"></i>
                  <i className="bi bi-star-fill text-yellow-400"></i>
                  <i className="bi bi-star-fill text-yellow-400"></i>
                  <i className="bi bi-star-fill text-yellow-400"></i>
                </div>
                <p className="testimonial-content flex-grow">{testimonial.text}</p>
              </div>
            </div>
          ))}
        </Slider>
        
        <div className="mt-12 text-center">
          <a href="#" className="btn btn-primary">
            View Before & After Gallery
          </a>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
